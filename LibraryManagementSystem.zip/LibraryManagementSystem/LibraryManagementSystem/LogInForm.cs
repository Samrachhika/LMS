﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class LogInForm : Form
    {
        public LogInForm()
        {
            InitializeComponent();
        }

        private void userLogInButton_Click(object sender, EventArgs e)
        {
            UserLogIn afterUserLogIn = new UserLogIn();
            //if role is student then open student page or open librarian page
            //afterUserLogIn.MdiParent =MainForm;
            afterUserLogIn.Show();
        }

        private void adminLogInButton_Click(object sender, EventArgs e)
        {
            AdminLogIn afterAdminLogIn = new AdminLogIn();
            afterAdminLogIn.Show();
        }
    }
}
